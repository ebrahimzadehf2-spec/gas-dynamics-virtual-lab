# Gas Dynamics Virtual Lab — v0.1

A real browser-based analytical compressible-flow laboratory accompanying *Introduction to Compressible Flows*. This is the first implementation increment, not complete coverage of every book section or acceptance of every worked example.

## Run and validate

No application dependencies, bundler, backend, Python runtime in the browser, or external CDN are required. Native ES modules and module Workers need an HTTP(S) origin; do not open index.html using file://.

```bash
npm test
python -m http.server 8080 --directory dist
```

Open http://localhost:8080. Node 22 or newer is sufficient for the test suite. Optional independent reference regeneration requires Python with SciPy:

```bash
python tests/independent_reference.py
npm test
```

## GitHub Pages

Create a repository, put the contents of this project at its root, and push to `main`. In repository Settings → Pages, choose **GitHub Actions**. The included `.github/workflows/pages.yml` runs the test suite and publishes `dist/`. Paths are relative, so a project subdirectory works without a base-path rewrite. The optional `.openai/hosting.json` belongs to the private preview host and is ignored by GitHub Pages. No GitHub repository has been created on the user's behalf.

## Implemented experiments

12 working experiments across 10 chapter entries: stagnation properties; conservation across a shock; normal shock; Rayleigh heating/cooling; Fanno; oblique shocks with weak/strong branches; Prandtl–Meyer expansion; unequal oblique-shock interaction; shock tube; quasi-1D nozzle regimes and shock area; linearized diamond airfoil; weak conical Taylor–Maccoll flow.

Every experiment has numeric controls, a calculated state, an SVG view, and a scientific chart. JSON/CSV/SVG export and a pinned same-experiment comparison are available. Inputs and one pinned state are saved locally in the browser. There is no telemetry, account system, or server-side persistence. The interface is primarily English; Persian chapter names are included. Full Persian localization remains planned.

## Architecture

- `dist/core/numerics.js`: typed errors, gas/input validation, bracketed bisection, peak search, units.
- `dist/core/physics.js`: pure thermodynamics and physics solvers; no DOM dependencies.
- `dist/core/cone.js`: Taylor–Maccoll IVP with RK4 step doubling, surface event refinement, outer weak-branch shooting.
- `dist/labs.js`: chapter/module registry, parameter schema, model assumptions, calculated rows and chart specifications.
- `dist/worker.js`: asynchronous scientific calculation; request IDs prevent stale results overwriting new inputs.
- `dist/graphics.js`: SVG scenes and scientific charts; labels distinguish schematics and analytical fields.
- `dist/app.js`: form controls, current state, comparison, local persistence and exports.
- `tests/`: physics, domain, integration, and independent-reference tests.

The zero-build JavaScript implementation is intentionally portable to GitHub Pages. Migration to TypeScript or a component framework can be done without changing the engine contract. Keeping physics functions independent of the UI is the main architectural boundary.

## Scientific conventions

Internal units: Pa, K, m/s, J/kg; angles in radians. Controls explicitly convert kPa, degrees, and kJ/kg. Calorically perfect ideal gas, `cp = gamma*R/(gamma-1)`; for gamma=1.4 and R=287, cp=1004.5 J/(kg K). Dimensional solvers use R=287 unless separately specified. Fanno uses **Darcy** `f_D L/D = 4 f_F L/D`.

No CFD, spatial mesh, two-dimensional Euler time marching, or SU2 connection exists. SVG shading is either explicitly schematic, piecewise analytical, quasi-1D, or angular similarity data. Moving tracers are illustrative except for the shock-tube similarity wave positions. The shock-tube solution is restricted to times before end-wall reflection; its displayed axis does not represent physical closed ends.

## Verification and open issues

20 test groups pass in the development runtime, including scientific reference cases, laws of conservation, root residuals, invalid inputs, heating/cooling limits, branch selection, shock location, and all registered default plots. Independent Python quadratic inversion checks four Rayleigh cases. SciPy DOP853 + Brent checks three conical cases independently of the JS RK algorithm. These are model/code verification checks, not experimental validation or full book-example acceptance.

The NASA cone10 page's quoted theory table has an unresolved discrepancy (details in docs/VALIDATION.md); it is not treated as an accepted golden fixture. Full browser testing of every slider combination and every mobile device is not claimed. Strong cone branches, detached shock geometry, wall reflections and general mixed outgoing wave patterns are not implemented.

See `docs/NOTEBOOK_AUDIT.md`, `docs/ROADMAP.md`, and the in-app `guide.html`.
